package organizzazioneBenefica;

import java.io.Serializable;

public class MessageWrapper implements Serializable{
    private Long id;
    private int donatori;

    public MessageWrapper(Long id, int donatori) {
        this.id = id;
        this.donatori = donatori;
    }

    public Long getId() {
        return id;
    }

    public int getDonatori() {
        return donatori;
    }
    
    
}
