package organizzazionebeneficastdclient;

import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import organizzazioneBenefica.*;

public class OrganizzazioneBeneficaStdClient {

    private static OrganizzazioneBeneficaEJBRemote organizzazioneEjb;

    public static void main(String[] args) throws NamingException {
        Context ctx = new InitialContext();
        
        organizzazioneEjb = (OrganizzazioneBeneficaEJBRemote) ctx.lookup("java:global/OrganizzazioneBeneficaBean/OrganizzazioneBeneficaEJB!organizzazioneBenefica.OrganizzazioneBeneficaEJBRemote");
        
        List<OrganizzazioneBenefica> list = organizzazioneEjb.trovaTutteOrganizzazioni();
        System.out.println("Tutte le organizzazioni:");
        for(OrganizzazioneBenefica o : list){
            System.out.println(o);
        }
        
        Float bilancio = 50000000.00F;
        stampaPerBilancio(bilancio);
    }
    
    public static void stampaPerBilancio(Float bilancio){
        System.out.println("Tutte le organizzazioni con bilancio 50000000:");
        List<OrganizzazioneBenefica> list = organizzazioneEjb.trovaPerBilancio(bilancio);
        for(OrganizzazioneBenefica o : list){
            System.out.println(o);
        }
    }
    
}
