package organizzazionebeneficawebserviceclient;

import java.util.List;

public class OrganizzazioneBeneficaWebServiceClient {

    public static void main(String[] args) {
        List<organizzazionebenefica.OrganizzazioneBenefica> list = trovaPerTrasparenza(100);
        for(organizzazionebenefica.OrganizzazioneBenefica b: list)
            System.out.println(b.getNome());
    }

    private static java.util.List<organizzazionebenefica.OrganizzazioneBenefica> trovaPerTrasparenza(int arg0) {
        organizzazionebenefica.OrganizzazioneBeneficaEJBService service = new organizzazionebenefica.OrganizzazioneBeneficaEJBService();
        organizzazionebenefica.OrganizzazioneBeneficaEJB port = service.getOrganizzazioneBeneficaEJBPort();
        return port.trovaPerTrasparenza(arg0);
    }
    
    
    
}
