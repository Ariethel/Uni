package torneoScacchi;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface PartitaEJBRemote {
    void aggiungiPartita(Partita p);
    Partita aggiornaPartita(Partita p);
    void rimuoviPartita(Partita p);
    
    Partita trovaPerID(int id);
    List<Partita> trovaTutti();
    List<Partita> trovaPerTipoPartita(String tipoPartita);
    List<Partita> trovaPerGiocatore(String nome);
    List<Partita> trovaPerRisultato(String risultato);
    List<Partita> trovaPerMosse(String mosse);
    List<Partita> trovaPerRating(int rating);
}
