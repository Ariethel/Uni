package torneoscacchistdclient;

import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import torneoScacchi.*;

public class TorneoScacchiStdClient {

    private static PartitaEJBRemote ejb;
    
    public static void main(String[] args) throws NamingException {
        Context ctx = new InitialContext();
        ejb = (PartitaEJBRemote) ctx.lookup("java:global/TorneoScacchi/PartitaEJB!torneoScacchi.PartitaEJBRemote");
        
        System.out.println("Trova tutte le partite con giocatori con rating maggiore di 2300");
        List<Partita> lista = ejb.trovaPerRating(2300);
        for(Partita p : lista)
            System.out.println(p);
        
        System.out.println("Trova tutte le partite finite in pareggio");
        lista = ejb.trovaPerRisultato("Patta");
        for(Partita p : lista)
            System.out.println(p);
        
        /*
        System.out.println("Trova per tipo partita");
        lista = ejb.trovaPerTipoPartita("Classic");
        for(Partita p : lista)
            System.out.println(p);
        
        System.out.println("Trova per giocatore");
        lista = ejb.trovaPerGiocatore("Nepomniachtchi");
        for(Partita p : lista)
            System.out.println(p);
        
        System.out.println("Trova per mosse");
        lista = ejb.trovaPerMosse("e4 e5 Nf3");
        for(Partita p : lista)
            System.out.println(p);

        */
        
    }
    
}
