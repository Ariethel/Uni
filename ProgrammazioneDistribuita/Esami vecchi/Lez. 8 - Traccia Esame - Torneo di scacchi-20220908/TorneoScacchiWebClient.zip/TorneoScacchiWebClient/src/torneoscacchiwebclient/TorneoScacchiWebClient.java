package torneoscacchiwebclient;

import java.util.List;
import torneoscacchi.Partita;

public class TorneoScacchiWebClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Partita> lista = trovaTutti();
        for(Partita p: lista)
            System.out.println("Partita{" + "id=" + p.getId() + ", tipo_partita=" + p.getTipoPartita() + ", g1=" + p.getG1() + ", g1_rating=" + p.getG1Rating() + ", g2=" + p.getG2() + ", g2_rating=" + p.getG2Rating() + ", mosse=" + p.getMosse() + ", risultato=" + p.getRisultato() + ", partita_conclusa=" + p.isPartitaConclusa() + '}');
    }

    private static java.util.List<torneoscacchi.Partita> trovaTutti() {
        torneoscacchi.PartitaEJBService service = new torneoscacchi.PartitaEJBService();
        torneoscacchi.PartitaEJB port = service.getPartitaEJBPort();
        return port.trovaTutti();
    }
    
}
