package torneoScacchi;

import javax.enterprise.event.Observes;

public class PareggioNotification {
    public void notify(@Observes @Pareggio Partita partita){
        System.out.println("Partita conclusa con pareggio");      
    }
}