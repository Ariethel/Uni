package torneoScacchi;

import java.io.Serializable;

public class MessageWrapper implements Serializable{
    private int id;
    private String mosse;
    private String risultato;

    public MessageWrapper(int id, String mosse, String risultato) {
        this.id = id;
        this.mosse = mosse;
        this.risultato = risultato;
    }

    public int getId() {
        return id;
    }

    public String getMosse() {
        return mosse;
    }

    public String getRisultato() {
        return risultato;
    }
    
    
}
