package torneoScacchi;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.NamedQuery;
import javax.persistence.TypedQuery;

@Stateless
@LocalBean
@WebService
public class PartitaEJB implements PartitaEJBRemote {

    @Inject
    private EntityManager em;
    
    @Override
    public void aggiungiPartita(Partita p) {
        em.persist(p);
    }

    @Override
    public Partita aggiornaPartita(Partita p) {
        return em.merge(p);
    }

    @Override
    public void rimuoviPartita(Partita p) {
        em.remove(em.merge(p));
    }

    @Override
    public Partita trovaPerID(int id) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_ID, Partita.class);
        query.setParameter(1, id);
        return query.getSingleResult();
    }

    @Override
    public List<Partita> trovaTutti() {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_TUTTI, Partita.class);
        return query.getResultList();
    }

    @Override
    public List<Partita> trovaPerTipoPartita(String tipoPartita) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_TIPO_PARTITA, Partita.class);
        query.setParameter("tipo_partita", tipoPartita);
        return query.getResultList();    
    }

    @Override
    public List<Partita> trovaPerGiocatore(String nome) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_GIOCATORI, Partita.class);
        query.setParameter("nome", nome);
        return query.getResultList();      
    }

    @Override
    public List<Partita> trovaPerRisultato(String risultato) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_RISULTATO, Partita.class);
        query.setParameter("risultato", risultato);
        return query.getResultList();  
    }

    @Override
    public List<Partita> trovaPerMosse(String mosse) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_MOSSE, Partita.class);
        query.setParameter("mosse", mosse);
        return query.getResultList();  
    }

    @Override
    public List<Partita> trovaPerRating(int rating) {
        TypedQuery<Partita> query = em.createNamedQuery(Partita.TROVA_PER_RATING, Partita.class);
        query.setParameter("rating", rating);
        return query.getResultList();  
    }

}
