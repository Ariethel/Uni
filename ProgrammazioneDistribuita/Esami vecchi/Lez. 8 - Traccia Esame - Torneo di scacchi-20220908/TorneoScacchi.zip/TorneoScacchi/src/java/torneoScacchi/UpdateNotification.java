package torneoScacchi;

import javax.enterprise.event.Observes;

public class UpdateNotification {
    public void notify(@Observes Partita partita){
        System.out.println(partita.getId() +" has been updated. Status: " + partita);
        
        if(partita.isPartita_conclusa() && !partita.getRisultato().equals("Patta"))
            if(partita.getRisultato().equals("G1") && partita.getG1_rating()>2800)
                System.out.println(partita.getG1() + " is a superplayer");
            else if(partita.getRisultato().equals("G2") && partita.getG2_rating()>2800)
                System.out.println(partita.getG2() + " is a superplayer");
            
    }
}