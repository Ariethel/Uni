package torneoScacchi;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;
import static torneoScacchi.Partita.TROVA_PER_TIPO_PARTITA;
import static torneoScacchi.Partita.TROVA_PER_GIOCATORI;
import static torneoScacchi.Partita.TROVA_PER_RISULTATO;
import static torneoScacchi.Partita.TROVA_PER_MOSSE;
import static torneoScacchi.Partita.TROVA_PER_ID;
import static torneoScacchi.Partita.TROVA_TUTTI;
import static torneoScacchi.Partita.TROVA_PER_RATING;

@Entity
@NamedQueries({
    @NamedQuery(name = TROVA_PER_TIPO_PARTITA, query = "SELECT p FROM Partita p WHERE p.tipo_partita = :tipo_partita"),
    @NamedQuery(name = TROVA_PER_GIOCATORI, query = "SELECT p FROM Partita p WHERE p.g1 = :nome OR p.g2 = :nome"),
    @NamedQuery(name = TROVA_PER_RISULTATO, query = "SELECT p FROM Partita p WHERE p.risultato = :risultato"),
    @NamedQuery(name = TROVA_PER_MOSSE, query= "SELECT p FROM Partita p WHERE p.mosse LIKE CONCAT('%', :mosse, '%')"),
    @NamedQuery(name = TROVA_PER_ID, query="SELECT p FROM Partita p WHERE p.id = ?1"),
    @NamedQuery(name = TROVA_TUTTI, query = "SELECT p FROM Partita p"),
    @NamedQuery(name = TROVA_PER_RATING, query="SELECT p FROM Partita p WHERE p.partita_conclusa = TRUE AND p.g1_rating>:rating AND p.g2_rating>:rating")
})
@XmlRootElement
public class Partita implements Serializable {
    public static final String TROVA_PER_TIPO_PARTITA = "Partita.trovaPerTipoPartita";
    public static final String TROVA_PER_GIOCATORI = "Partita.trovaPerGiocatori";
    public static final String TROVA_PER_RISULTATO = "Partita.trovaPerRisultato";
    public static final String TROVA_PER_MOSSE = "Partita.trovaPerMosse";
    public static final String TROVA_PER_ID = "Partita.trovaPerID";
    public static final String TROVA_PER_RATING = "Partita.trovaPerRating";
    public static final String TROVA_TUTTI = "Partita.trovaTutti";
    
    @Id
    private int id;
    private String tipo_partita;
    private String g1;
    private int g1_rating;
    private String g2;
    private int g2_rating;
    private String mosse;
    private String risultato;
    private boolean partita_conclusa;

    public Partita() {}

    public Partita(int id, String tipo_partita, String g1, int g1_rating, String g2, int g2_rating, String mosse, String risultato, boolean partita_conclusa) {
        this.id = id;
        this.tipo_partita = tipo_partita;
        this.g1 = g1;
        this.g1_rating = g1_rating;
        this.g2 = g2;
        this.g2_rating = g2_rating;
        this.mosse = mosse;
        this.risultato = risultato;
        this.partita_conclusa = partita_conclusa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo_partita() {
        return tipo_partita;
    }

    public void setTipo_partita(String tipo_partita) {
        this.tipo_partita = tipo_partita;
    }

    public String getG1() {
        return g1;
    }

    public void setG1(String g1) {
        this.g1 = g1;
    }

    public int getG1_rating() {
        return g1_rating;
    }

    public void setG1_rating(int g1_rating) {
        this.g1_rating = g1_rating;
    }

    public String getG2() {
        return g2;
    }

    public void setG2(String g2) {
        this.g2 = g2;
    }

    public int getG2_rating() {
        return g2_rating;
    }

    public void setG2_rating(int g2_rating) {
        this.g2_rating = g2_rating;
    }

    public String getMosse() {
        return mosse;
    }

    public void setMosse(String mosse) {
        this.mosse = mosse;
    }

    public String getRisultato() {
        return risultato;
    }

    public void setRisultato(String risultato) {
        this.risultato = risultato;
    }

    public boolean isPartita_conclusa() {
        return partita_conclusa;
    }

    public void setPartita_conclusa(boolean partita_conclusa) {
        this.partita_conclusa = partita_conclusa;
    }

    @Override
    public String toString() {
        return "Partita{" + "id=" + id + ", tipo_partita=" + tipo_partita + ", g1=" + g1 + ", g1_rating=" + g1_rating + ", g2=" + g2 + ", g2_rating=" + g2_rating + ", mosse=" + mosse + ", risultato=" + risultato + ", partita_conclusa=" + partita_conclusa + '}';
    } 
    
}
