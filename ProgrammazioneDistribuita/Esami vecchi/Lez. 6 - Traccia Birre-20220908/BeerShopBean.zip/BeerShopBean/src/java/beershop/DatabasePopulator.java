package beershop;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/BeerShopDS",
   user = "ok", password = "ok",
   databaseName = "BeerShopDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private BeerShopEJB shopEjb;
    private BeerShop shop1, shop2, shop3;
    
    @PostConstruct
    private void populateDB(){
        shop1 = new BeerShop(1, "BeviBene", "John", 430015, 132210, "Napoli", "Napoli", "Campania");
        shop2 = new BeerShop(2, "BirraESaiCosaBevi", "Nanni Moretti", 640000, 212133, "Roma", "Roma", "Lazio");
        shop3 = new BeerShop(3, "BirreOggi", "Pasquale Poretti", 345941, 615231, "Cernusco", "Milano", "Lombardia");
        
        shopEjb.addBeerShop(shop1);
        shopEjb.addBeerShop(shop2);
        shopEjb.addBeerShop(shop3);
    }
    
    @PreDestroy
    private void clearDB(){
        shopEjb.removeBeerShop(shop1);
        shopEjb.removeBeerShop(shop2);
        shopEjb.removeBeerShop(shop3);
    }
    
    
}
