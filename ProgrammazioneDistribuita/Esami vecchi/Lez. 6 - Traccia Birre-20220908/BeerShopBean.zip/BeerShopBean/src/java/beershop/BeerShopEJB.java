package beershop;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import static beershop.BeerShop.FIND_ALL;
import static beershop.BeerShop.FIND_BY_ID;
import static beershop.BeerShop.FIND_BY_REGION;
import static beershop.BeerShop.FIND_DRUNK_PEOPLE_SHOPS;
import javax.enterprise.event.Event;

@Stateless
@LocalBean
@WebService
public class BeerShopEJB implements BeerShopEJBRemote {
    @Inject
    private EntityManager em;

    @Override
    public void addBeerShop(BeerShop shop) {
        em.persist(shop);
    }

    @Override
    public void removeBeerShop(BeerShop shop) {
        em.remove(em.merge(shop));
    }

    @Override
    public BeerShop updateBeerShop(BeerShop shop) {
        return em.merge(shop);
    }
    
    @Override
    public List<BeerShop> findAllBeerShops() {
        TypedQuery<BeerShop> query = em.createNamedQuery(FIND_ALL, BeerShop.class);
        return query.getResultList();
    }
    
    @Override
    public List<BeerShop> findAllDrunkPeopleShops() {
        TypedQuery<BeerShop> query = em.createNamedQuery(FIND_DRUNK_PEOPLE_SHOPS, BeerShop.class);
        return query.getResultList();
    }

    @Override
    public BeerShop findById(int id) {
        TypedQuery<BeerShop> query = em.createNamedQuery(FIND_BY_ID, BeerShop.class);
        query.setParameter("id", id);
        return query.getSingleResult();
    }
    
    @Override
    @Loggable
    public List<BeerShop> findByRegion(String region) {
        TypedQuery<BeerShop> query = em.createNamedQuery(FIND_BY_REGION, BeerShop.class);
        query.setParameter("region", region);
        return query.getResultList();
    }
    
    @Inject
    Event<BeerShop> event;
    
    public void updateDirector(int id, String director){
        BeerShop shop = findById(id);
        shop.setDirector(director);
        updateBeerShop(shop);
        event.fire(shop);
    }

}
