package beershop;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@Loggable
public class LoggingInterceptor {
    private Integer counter = 0;
    @AroundInvoke
    public Object logMethod(InvocationContext ic) throws Exception{
        ++counter;
        System.out.println("Metodo " + ic.getMethod().getName() + " chiamato " + counter + " volte");
        
        return ic.proceed();

    } 
       
}
