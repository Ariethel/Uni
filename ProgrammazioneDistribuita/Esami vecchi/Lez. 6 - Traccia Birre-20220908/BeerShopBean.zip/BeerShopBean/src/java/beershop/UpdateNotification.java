package beershop;

import javax.enterprise.event.Observes;

public class UpdateNotification {
    public void notify(@Observes BeerShop shop){
        System.out.println(shop.getId() +" has been updated. Status: " + shop);
    }
}