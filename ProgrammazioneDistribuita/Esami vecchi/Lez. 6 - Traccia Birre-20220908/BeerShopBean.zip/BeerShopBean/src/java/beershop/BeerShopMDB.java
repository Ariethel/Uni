package beershop;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

@MessageDriven(mappedName = "jms/javaee7/Topic1")
public class BeerShopMDB implements MessageListener {
    
    @Inject
    private BeerShopEJB shopejb;

    @Override
    public void onMessage(Message msg) {
        try {
            MessageWrapper msgContent = msg.getBody(MessageWrapper.class);
            int id = msgContent.getId();
            int itemsSold = msgContent.getAlcoholicSoldAleUpdate();
            BeerShop s = shopejb.findById(id);
            s.setAlcoholicSoldAle(s.getAlcoholicSoldAle()+itemsSold);
            s = shopejb.updateBeerShop(s);
            
            Context cxt = new InitialContext();
            ConnectionFactory cf = (ConnectionFactory) cxt.lookup("jms/javaee7/ConnectionFactory");
            Destination topic = (Destination) cxt.lookup("jms/javaee7/Topic2");
                
            try(JMSContext jmsCxt = cf.createContext()){
                jmsCxt.createProducer().
                    send(topic, true);            
            }
        } catch (JMSException ex) {
            Logger.getLogger(BeerShopMDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NamingException ex) {
            Logger.getLogger(BeerShopMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
