package beershop;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import static beershop.BeerShop.FIND_ALL;
import static beershop.BeerShop.FIND_BY_ID;
import static beershop.BeerShop.FIND_BY_REGION;
import static beershop.BeerShop.FIND_DRUNK_PEOPLE_SHOPS;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries({
    @NamedQuery(name = FIND_ALL, query = "SELECT s FROM BeerShop s"),
    @NamedQuery(name = FIND_BY_REGION, query = "SELECT s FROM BeerShop s WHERE s.region = :region"),
    @NamedQuery(name = FIND_BY_ID, query = "SELECT s FROM BeerShop s WHERE s.id = :id"),
    @NamedQuery(name = FIND_DRUNK_PEOPLE_SHOPS, query = "SELECT s FROM BeerShop s WHERE s.alcoholicSoldAle > s.analcoholicSoldAle")
})
@Entity
@XmlRootElement
public class BeerShop implements Serializable {
    private static final long serialVersionUID = 1L;
    
    public static final String FIND_ALL = "BeerShop.findAll";
    public static final String FIND_BY_ID = "BeerShop.findById";
    public static final String FIND_BY_REGION = "BeerShop.findByRegion";
    public static final String FIND_DRUNK_PEOPLE_SHOPS = "BeerShop.findDrunkPeopleShops";
    
    @Id 
    private int id;
    private String name;
    private String director;
    private Integer alcoholicSoldAle;
    private Integer analcoholicSoldAle;
    private String city;
    private String provice;
    private String region;

    public BeerShop() {
    }

    public BeerShop(int id, String name, String director, Integer alcoholicSoldAle, Integer analcoholicSoldAle, String city, String provice, String region) {
        this.id = id;
        this.name = name;
        this.director = director;
        this.alcoholicSoldAle = alcoholicSoldAle;
        this.analcoholicSoldAle = analcoholicSoldAle;
        this.city = city;
        this.provice = provice;
        this.region = region;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public Integer getAlcoholicSoldAle() {
        return alcoholicSoldAle;
    }

    public void setAlcoholicSoldAle(Integer alcoholicSoldAle) {
        this.alcoholicSoldAle = alcoholicSoldAle;
    }

    public Integer getAnalcoholicSoldAle() {
        return analcoholicSoldAle;
    }

    public void setAnalcoholicSoldAle(Integer analcoholicSoldAle) {
        this.analcoholicSoldAle = analcoholicSoldAle;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvice() {
        return provice;
    }

    public void setProvice(String provice) {
        this.provice = provice;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Override
    public String toString() {
        return "BeerShop{" + "id=" + id + ", name=" + name + ", director=" + director + ", alcoholicSoldAle=" + alcoholicSoldAle + ", analcoholicSoldAle=" + analcoholicSoldAle + ", city=" + city + ", provice=" + provice + ", region=" + region + '}';
    }

    
}
