package beershopjmsconsumer;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BeerShopJMSConsumer {

    public static void main(String[] args) throws NamingException {
        Context cxt = new InitialContext();
        ConnectionFactory cf = (ConnectionFactory) cxt.lookup("jms/javaee7/ConnectionFactory");
        Destination topic = (Destination) cxt.lookup("jms/javaee7/Topic2");
        
        try(JMSContext jmsCxt = cf.createContext()){
            while(true){
                Boolean msgContent = jmsCxt.createConsumer(topic).
                        receiveBody(Boolean.class);
                System.out.println("Aggiornamento avvenuto");
            }
        }
    }
    
}
