package beershop;

import java.io.Serializable;

public class MessageWrapper implements Serializable{
    private int id;
    private int alcoholicSoldAleUpdate;

    public MessageWrapper(int id, int alcoholicSoldAleUpdate) {
        this.id = id;
        this.alcoholicSoldAleUpdate = alcoholicSoldAleUpdate;
    }

    public int getId() {
        return id;
    }

    public int getAlcoholicSoldAleUpdate() {
        return alcoholicSoldAleUpdate;
    }
    
    
}
