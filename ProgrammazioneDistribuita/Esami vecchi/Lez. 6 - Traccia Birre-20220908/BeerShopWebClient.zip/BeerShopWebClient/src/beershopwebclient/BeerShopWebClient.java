package beershopwebclient;

public class BeerShopWebClient {

    public static void main(String[] args) {
        updateDirector(3, "Moretti");
    }

    private static void updateDirector(int arg0, java.lang.String arg1) {
        beershop.BeerShopEJBService service = new beershop.BeerShopEJBService();
        beershop.BeerShopEJB port = service.getBeerShopEJBPort();
        port.updateDirector(arg0, arg1);
    }
    
}
