package beershopstdclient;

import beershop.BeerShop;
import beershop.BeerShopEJBRemote;
import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BeerShopStdClient {

    private static BeerShopEJBRemote shopEJB;
    
    public static void main(String[] args) throws NamingException {
        
        Context ctx = new InitialContext();
        
        shopEJB = (BeerShopEJBRemote) ctx.lookup("java:global/BeerShopBean/BeerShopEJB!beershop.BeerShopEJBRemote");
        
        System.out.print("Scrivi una regione:");
        Scanner scanner = new Scanner(System.in);
        String region = scanner.nextLine();
        printByRegion(region);
        
        printDrunkPeopleShops();
    }
    
    private static void printByRegion(String region){
        System.out.println("Ecco i negozi di birra in " + region);
        List<BeerShop> shops = shopEJB.findByRegion(region);
        for(BeerShop b: shops){
            System.out.println(b);
        }
    }
    
    private static void printDrunkPeopleShops(){
        System.out.println("Ecco i negozi dove si vendono pi� bevande alcoline che analcoliche");
        List<BeerShop> shops = shopEJB.findAllDrunkPeopleShops();
        for(BeerShop b: shops){
            System.out.println(b);
        }
    }
    
}
