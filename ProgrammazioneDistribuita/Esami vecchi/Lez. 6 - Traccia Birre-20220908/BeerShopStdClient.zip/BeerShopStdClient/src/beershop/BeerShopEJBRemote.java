package beershop;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface BeerShopEJBRemote {
    void addBeerShop(BeerShop s);
    void removeBeerShop(BeerShop s);
    BeerShop updateBeerShop(BeerShop s);
    
    List<BeerShop> findAllBeerShops();
    BeerShop findById(int id);
    List<BeerShop> findByRegion(String region);
    List<BeerShop> findAllDrunkPeopleShops();
}
