package canilewebclient;

import java.util.List;

public class CanileWebClient {

    public static void main(String[] args) {
        List<canile.Cane> lista = trovaPerStatusAdozione(true);
        for(canile.Cane c: lista)
            System.out.println("Cane: id = " + c.getId() + ", taglia = " + c.getTaglia() + ", eta = " + c.getEta() + ", status adozione = " + c.isStatusAdozione());
    }

    private static java.util.List<canile.Cane> trovaPerStatusAdozione(boolean arg0) {
        canile.CaneEJBService service = new canile.CaneEJBService();
        canile.CaneEJB port = service.getCaneEJBPort();
        return port.trovaPerStatusAdozione(arg0);
    }
    
}
