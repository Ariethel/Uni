package canilestdclient;

import canile.*;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CanileStdClient {

    private static CaneEJBRemote ejb;
    
    public static void main(String[] args) throws NamingException {
        Context cxt = new InitialContext();
        ejb = (CaneEJBRemote) cxt.lookup("java:global/Canile/CaneEJB!canile.CaneEJBRemote");
        
        System.out.println("Tutti i cani di taglia piccola e di età maggiore o uguale a 8 anni. ");
        List<Cane> lista = ejb.trovaPerTagliaEdEta("Piccola", "8+");
        for(Cane c: lista)
            System.out.println(c);

        System.out.println("Tutti i cani non ancora adottati. ");        
        lista = ejb.trovaPerStatusAdozione(false);
        for(Cane c: lista)
            System.out.println(c);

        ejb.adotta(1);
        
    }
    
}
