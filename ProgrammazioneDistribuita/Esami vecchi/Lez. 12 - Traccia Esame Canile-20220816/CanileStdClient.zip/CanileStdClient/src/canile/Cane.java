package canile;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import static canile.Cane.*;
import java.io.Serializable;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@NamedQueries({
    @NamedQuery(name = FIND_BY_ID, query = "SELECT c FROM Cane c WHERE c.id = ?1"),
    @NamedQuery(name = FIND_BY_RAZZA, query = "SELECT c FROM Cane c WHERE c.razza = :razza"),
    @NamedQuery(name = FIND_BY_NOME, query = "SELECT c FROM Cane c WHERE c.nome = :nome"),
    @NamedQuery(name = FIND_BY_TAGLIA, query = "SELECT c FROM Cane c WHERE c.taglia = :taglia"),
    @NamedQuery(name = FIND_BY_ETA, query = "SELECT c FROM Cane c WHERE c.eta = :eta"),
    @NamedQuery(name = FIND_BY_STATUS_ADOZIONE, query = "SELECT c FROM Cane c WHERE c.statusAdozione = :status"),
    @NamedQuery(name = FIND_ALL, query = "SELECT c FROM Cane c "),
    @NamedQuery(name = FIND_BY_TAGLIA_AND_ETA, query = "SELECT c FROM Cane c WHERE c.eta = :eta AND c.taglia = :taglia")    
})
@XmlRootElement
public class Cane implements Serializable {
    public static final String FIND_BY_ID = "Cane.FindByID";
    public static final String FIND_BY_RAZZA = "Cane.FindByRazza";
    public static final String FIND_BY_NOME = "Cane.findByNome";
    public static final String FIND_BY_TAGLIA = "Cane.findByTaglia";
    public static final String FIND_BY_ETA = "Cane.findByEta";
    public static final String FIND_BY_STATUS_ADOZIONE = "Cane.findByStatusAdozione";
    public static final String FIND_ALL = "Cane.findAll";
    public static final String FIND_BY_TAGLIA_AND_ETA = "Cane.findByTagliaAndEta";
    
    @Id
    private int id;
    private String razza;
    private String nome;
    private String taglia;
    private String sesso;
    private String eta;
    private long microchip;
    private boolean statusAdozione;

    public Cane() {
    }

    public Cane(int id, String razza, String nome, String taglia, String sesso, String eta, long microchip, boolean statusAdozione) {
        this.id = id;
        this.razza = razza;
        this.nome = nome;
        this.taglia = taglia;
        this.sesso = sesso;
        this.eta = eta;
        this.microchip = microchip;
        this.statusAdozione = statusAdozione;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRazza() {
        return razza;
    }

    public void setRazza(String razza) {
        this.razza = razza;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTaglia() {
        return taglia;
    }

    public void setTaglia(String taglia) {
        this.taglia = taglia;
    }

    public String getSesso() {
        return sesso;
    }

    public void setSesso(String sesso) {
        this.sesso = sesso;
    }

    public String getEta() {
        return eta;
    }

    public void setEta(String eta) {
        this.eta = eta;
    }

    public long getMicrochip() {
        return microchip;
    }

    public void setMicrochip(long microchip) {
        this.microchip = microchip;
    }

    public boolean isStatusAdozione() {
        return statusAdozione;
    }

    public void setStatusAdozione(boolean statusAdozione) {
        this.statusAdozione = statusAdozione;
    }

    @Override
    public String toString() {
        return "Cane{" + "id=" + id + ", razza=" + razza + ", nome=" + nome + ", taglia=" + taglia + ", sesso=" + sesso + ", eta=" + eta + ", microchip=" + microchip + ", statusAdozione=" + statusAdozione + '}';
    }
    
}   
