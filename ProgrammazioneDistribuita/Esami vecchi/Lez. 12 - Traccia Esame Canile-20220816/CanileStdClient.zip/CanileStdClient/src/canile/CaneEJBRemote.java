package canile;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface CaneEJBRemote {
    void aggiungiCane(Cane c);
    Cane aggiornaCane(Cane c);
    void rimuoviCane(Cane c);
    
    Cane trovaPerID(int id);
    List<Cane> trovaPerRazza(String razza);
    List<Cane> trovaPerNome(String nome);
    List<Cane> trovaPerTaglia(String taglia);
    List<Cane> tovaPerEta(String eta);
    List<Cane> trovaPerStatusAdozione(boolean status);
    List<Cane> trovaTutti();
    List<Cane> trovaPerTagliaEdEta(String taglia, String eta);
    
    void adotta(int id);
}
