package canile;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateless
@LocalBean
@WebService
@Counter
public class CaneEJB implements CaneEJBRemote {

    @Inject
    private EntityManager em;
    
    @Override
    public void aggiungiCane(Cane c) {
        em.persist(c);
    }

    @Override
    public Cane aggiornaCane(Cane c) {
        return em.merge(c);
    }

    @Override
    public void rimuoviCane(Cane c) {
        em.remove(em.merge(c));
    }

    @Override
    public Cane trovaPerID(int id) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_ID, Cane.class);
        query.setParameter(1, id);
        return query.getSingleResult();
    }

    @Override
    public List<Cane> trovaPerRazza(String razza) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_RAZZA, Cane.class);
        query.setParameter("razza", razza);
        return query.getResultList();
    }

    @Override
    public List<Cane> trovaPerNome(String nome) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_NOME, Cane.class);
        query.setParameter("nome", nome);
        return query.getResultList();
    }

    @Override
    public List<Cane> trovaPerTaglia(String taglia) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_TAGLIA, Cane.class);
        query.setParameter("taglia", taglia);
        return query.getResultList();
    }

    @Override
    public List<Cane> tovaPerEta(String eta) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_ETA, Cane.class);
        query.setParameter("eta", eta);
        return query.getResultList();
    }

    @Override
    public List<Cane> trovaPerStatusAdozione(boolean status) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_STATUS_ADOZIONE, Cane.class);
        query.setParameter("status", status);
        return query.getResultList();
    }

    @Override
    public List<Cane> trovaTutti() {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_ALL, Cane.class);
        return query.getResultList();
    }

    @Override
    public List<Cane> trovaPerTagliaEdEta(String taglia, String eta) {
        TypedQuery<Cane> query = em.createNamedQuery(Cane.FIND_BY_TAGLIA_AND_ETA, Cane.class);
        query.setParameter("taglia", taglia);
        query.setParameter("eta", eta);
        return query.getResultList();
    }
    
    @Override
    @CheckParameter
    public void adotta(int id){
        Cane c = trovaPerID(id);
        c.setStatusAdozione(true);
        em.merge(c);
    }

}
