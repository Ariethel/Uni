package canile;

import java.util.HashMap;
import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@CheckParameter
public class CheckParameterInterceptor {
    
    @Inject
    private CaneEJB ejb;
    
    @AroundInvoke
    public Object logMethod(InvocationContext ic) throws Exception{
        int id = (int) ic.getParameters()[0];
        Cane c = ejb.trovaPerID(id);
        if(c.isStatusAdozione()){
            System.out.println("L'operazione non è andata a buon fine");
            return null;
        }
            
        return ic.proceed();
    } 
}