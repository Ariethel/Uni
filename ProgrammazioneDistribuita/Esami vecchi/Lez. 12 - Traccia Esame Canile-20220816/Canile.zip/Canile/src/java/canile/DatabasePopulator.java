package canile;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/EsameDS",
   user = "ok", password = "ok",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private CaneEJB ejb;
    private Cane c1, c2, c3, c4;
    
    @PostConstruct
    private void populateDB(){
        c1 = new Cane(1, "Meticcio", "Leo", "Piccola", "M" , "0-2", 941000001156168L, true);
        c2 = new Cane(2, "Meticcio", "Luna", "Piccola", "F", "8+", 380260041762325L, true);
        c3 = new Cane(3, "Boston terrier", "Eros", "Media", "M", "8+", 941000001581506L, false);
        c4 = new Cane(4, "Pastore tedesco", "Pan", "Grande", "F", "3-7", 981100000297746L, true);
        
        ejb.aggiungiCane(c1);
        ejb.aggiungiCane(c2);
        ejb.aggiungiCane(c3);
        ejb.aggiungiCane(c4);
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviCane(c1);
        ejb.rimuoviCane(c2);
        ejb.rimuoviCane(c3);
        ejb.rimuoviCane(c4);
    }
    
    
}