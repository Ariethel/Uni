package canile;

import java.util.HashMap;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@Counter
public class CounterInterceptor {
    private HashMap<String, Integer> counterMap = new HashMap<String, Integer>();
    private String max_method;
    private int max_method_call_number = 0;
    
    @AroundInvoke
    public Object logMethod(InvocationContext ic) throws Exception{
        if(!counterMap.containsKey(ic.getMethod().getName()))
            counterMap.put(ic.getMethod().getName(), 0);
        counterMap.put(ic.getMethod().getName(),counterMap.get(ic.getMethod().getName())+1);
                
        if(counterMap.get(ic.getMethod().getName())>max_method_call_number){
            max_method = ic.getMethod().getName();
            max_method_call_number = counterMap.get(ic.getMethod().getName());
        }
        
        System.out.println("Invocato metodo " + ic.getMethod().getName() + ", "
                + "numero invocazioni " + counterMap.get(ic.getMethod().getName()) + ""
                + ". Metodo con massimo numero di invocazioni " + max_method + ""
                + ", numero invocazioni massime " + max_method_call_number);
        
        return ic.proceed();
    } 
}