package agenziaviaggistdclient;

import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import viaggi.*;

public class AgenziaViaggiStdClient {

    private static PropostaViaggioEJBRemote ejb;
    public static void main(String[] args) throws NamingException {
        Context cxt = new InitialContext();
        ejb = (PropostaViaggioEJBRemote) cxt.lookup("java:global/AgenziaViaggi/PropostaViaggioEJB!viaggi.PropostaViaggioEJBRemote");
        
        System.out.println("Qual è il tuo budget?");
        Scanner scanner = new Scanner(System.in);
        int prezzo = scanner.nextInt(); 
        // con 501, risultato atteso 1 e 2
        List<PropostaViaggio> lista = ejb.trovaPerPrezzo(prezzo);
        for(PropostaViaggio p:lista)
            System.out.println(p);
        
    }
    
}
