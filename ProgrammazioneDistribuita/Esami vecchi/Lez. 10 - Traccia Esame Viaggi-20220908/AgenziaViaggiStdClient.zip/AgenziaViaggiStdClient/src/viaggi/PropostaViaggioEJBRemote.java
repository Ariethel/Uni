package viaggi;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface PropostaViaggioEJBRemote {
    void aggiungiProposta(PropostaViaggio p);
    PropostaViaggio aggiornaProposta(PropostaViaggio p);
    void rimuoviProposta(PropostaViaggio p);
    
    PropostaViaggio trovaPerId(int id);
    List<PropostaViaggio> trovaPerDestinazione(String destinazione);
    List<PropostaViaggio> trovaPerCategoria(String categoria);
    List<PropostaViaggio> trovaPerPrezzo(int prezzo);
    List<PropostaViaggio> trovaTutte();
}
