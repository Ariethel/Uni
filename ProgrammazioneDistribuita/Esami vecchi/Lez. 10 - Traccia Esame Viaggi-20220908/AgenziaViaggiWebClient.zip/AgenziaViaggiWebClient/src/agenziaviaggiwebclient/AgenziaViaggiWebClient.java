package agenziaviaggiwebclient;

import java.util.List;
import viaggi.PropostaViaggio;

public class AgenziaViaggiWebClient {
    
    public static void main(String[] args) {
        List<PropostaViaggio> lista = trovaTutte();
        for(PropostaViaggio p : lista)
            System.out.println("Proposta per vacanza " + p.getCategoria() + " per "+ p.getDestinazione() + " a "+ p.getPrezzo() + " con " + p.getSconto() + " di sconto.");
    }

    private static java.util.List<viaggi.PropostaViaggio> trovaTutte() {
        viaggi.PropostaViaggioEJBService service = new viaggi.PropostaViaggioEJBService();
        viaggi.PropostaViaggioEJB port = service.getPropostaViaggioEJBPort();
        return port.trovaTutte();
    }
    
}
