package viaggi;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName = "jms/javaee7/Topic")
public class PropostaViaggioMDB implements MessageListener {
    
    @Inject
    private PropostaViaggioEJB ejb;

    @Inject 
    Event<PropostaViaggio> event;
    
    @Override
    public void onMessage(Message msg) {
        try {
            MessageWrapper wrapper = msg.getBody(MessageWrapper.class);
            
            Integer id = wrapper.getId();
            Integer sconto = wrapper.getSconto();
            
            PropostaViaggio p = ejb.trovaPerId(id);
            p.setSconto(p.getSconto()+sconto);
            if(p.getCategoria().equals("Montagna"))
                p.setSconto(p.getSconto()+5);
            p = ejb.aggiornaProposta(p);
            
            event.fire(p);
        } catch (JMSException ex) {
            Logger.getLogger(PropostaViaggioMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}