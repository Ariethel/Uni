package viaggi;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateless
@LocalBean
@WebService
public class PropostaViaggioEJB implements PropostaViaggioEJBRemote {

    @Inject
    private EntityManager em;

    @Override
    public void aggiungiProposta(PropostaViaggio p) {
        em.persist(p);
    }

    @Override
    public PropostaViaggio aggiornaProposta(PropostaViaggio p) {
        return em.merge(p);
    }

    @Override
    public void rimuoviProposta(PropostaViaggio p) {
        em.remove(em.merge(p));
    }

    @Override
    public PropostaViaggio trovaPerId(int id) {
        TypedQuery<PropostaViaggio> query = em.createNamedQuery(PropostaViaggio.TROVA_PER_ID, PropostaViaggio.class);
        query.setParameter(1, id);
        return query.getSingleResult();
    }

    @Override
    public List<PropostaViaggio> trovaPerDestinazione(String destinazione) {
        TypedQuery<PropostaViaggio> query = em.createNamedQuery(PropostaViaggio.TROVA_PER_DESTINAZIONE, PropostaViaggio.class);
        query.setParameter("destinazione", destinazione);
        return query.getResultList();
    }

    @Override
    public List<PropostaViaggio> trovaPerCategoria(String categoria) {
        TypedQuery<PropostaViaggio> query = em.createNamedQuery(PropostaViaggio.TROVA_PER_CATEGORIA, PropostaViaggio.class);
        query.setParameter("categoria", categoria);
        return query.getResultList();
    }

    @Override
    public List<PropostaViaggio> trovaPerPrezzo(int prezzo) {
        TypedQuery<PropostaViaggio> query = em.createNamedQuery(PropostaViaggio.TROVA_PER_PREZZO, PropostaViaggio.class);
        query.setParameter("prezzo", prezzo);
        return query.getResultList();
    }

    @Override
    public List<PropostaViaggio> trovaTutte() {
        TypedQuery<PropostaViaggio> query = em.createNamedQuery(PropostaViaggio.TROVA_TUTTE, PropostaViaggio.class);
        return query.getResultList();
    }
        
}
