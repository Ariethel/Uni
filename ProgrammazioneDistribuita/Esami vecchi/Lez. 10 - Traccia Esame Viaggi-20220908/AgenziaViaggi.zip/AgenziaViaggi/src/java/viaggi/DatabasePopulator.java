package viaggi;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/EsameDS",
   user = "ok", password = "ok",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private PropostaViaggioEJB ejb;
    private PropostaViaggio p1, p2, p3;
    
    @PostConstruct
    private void populateDB(){
        p1 = new PropostaViaggio(1, "Mare", "Seychelles", 3, 500, 10, 10);
        p2 = new PropostaViaggio(2, "Mare", "Corfù", 5, 200, 0, 20);
        p3 = new PropostaViaggio(3, "Montagna", "Cortina", 1, 700, 20, 30);
        
        ejb.aggiungiProposta(p1);
        ejb.aggiungiProposta(p2);
        ejb.aggiungiProposta(p3);
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviProposta(p1);
        ejb.rimuoviProposta(p2);
        ejb.rimuoviProposta(p3);
    }
    
    
}