package viaggi;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.xml.bind.annotation.XmlRootElement;
import static viaggi.PropostaViaggio.*;

@Entity
@NamedQueries({
    @NamedQuery(name = TROVA_PER_ID, query = "SELECT p FROM PropostaViaggio p WHERE p.id = ?1"),
    @NamedQuery(name = TROVA_PER_DESTINAZIONE, query = "SELECT p FROM PropostaViaggio p WHERE p.destinazione = :destinazione"),
    @NamedQuery(name = TROVA_PER_CATEGORIA, query = "SELECT p FROM PropostaViaggio p WHERE p.categoria = :categoria"),
    @NamedQuery(name = TROVA_TUTTE, query = "SELECT p FROM PropostaViaggio p"),
    @NamedQuery(name = TROVA_PER_PREZZO, query = "SELECT p FROM PropostaViaggio p WHERE p.prezzo < :prezzo")
})
@XmlRootElement

public class PropostaViaggio implements Serializable {
    public static final String TROVA_PER_ID = "PropostaViaggio.trovaPerId";
    public static final String TROVA_PER_DESTINAZIONE = "PropostaViaggio.trovaPerDestinazione";
    public static final String TROVA_PER_CATEGORIA = "PropostaViaggio.trovaPerCategoria";
    public static final String TROVA_PER_PREZZO = "PropostaViaggio.trovaPerPrezzo";
    public static final String TROVA_TUTTE = "PropostaViaggio.trovaTutte";
    
    @Id
    private int id;
    private String categoria;
    private String destinazione;
    private int numero_pacchetti;
    private int prezzo;
    private int sconto;
    private int disponibilita;

    public PropostaViaggio() {
    }

    public PropostaViaggio(int id, String categoria, String destinazione, int numero_pacchetti, int prezzo, int sconto, int disponibilita) {
        this.id = id;
        this.categoria = categoria;
        this.destinazione = destinazione;
        this.numero_pacchetti = numero_pacchetti;
        this.prezzo = prezzo;
        this.sconto = sconto;
        this.disponibilita = disponibilita;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDestinazione() {
        return destinazione;
    }

    public void setDestinazione(String destinazione) {
        this.destinazione = destinazione;
    }

    public int getNumero_pacchetti() {
        return numero_pacchetti;
    }

    public void setNumero_pacchetti(int numero_pacchetti) {
        this.numero_pacchetti = numero_pacchetti;
    }

    public int getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = prezzo;
    }

    public int getSconto() {
        return sconto;
    }

    public void setSconto(int sconto) {
        this.sconto = sconto;
    }

    public int getDisponibilita() {
        return disponibilita;
    }

    public void setDisponibilita(int disponibilita) {
        this.disponibilita = disponibilita;
    }

    @Override
    public String toString() {
        return "PropostaViaggio{" + "id=" + id + ", categoria=" + categoria + ", destinazione=" + destinazione + ", numero_pacchetti=" + numero_pacchetti + ", prezzo=" + prezzo + ", sconto=" + sconto + ", disponibilita=" + disponibilita + '}';
    }

    
}
