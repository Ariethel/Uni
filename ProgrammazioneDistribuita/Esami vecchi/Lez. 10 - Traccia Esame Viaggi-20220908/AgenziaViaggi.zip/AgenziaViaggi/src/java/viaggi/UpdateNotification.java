package viaggi;

import javax.enterprise.event.Observes;

public class UpdateNotification {
    public void notify(@Observes PropostaViaggio p){
        System.out.println("Aggiornamento effettuato: " + p);
    }
}