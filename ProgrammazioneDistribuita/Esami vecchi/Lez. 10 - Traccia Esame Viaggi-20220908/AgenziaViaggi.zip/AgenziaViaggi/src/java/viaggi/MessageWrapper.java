package viaggi;

import java.io.Serializable;

public class MessageWrapper implements Serializable {
    private int id;
    private int sconto;

    public MessageWrapper(int id, int sconto) {
        this.id = id;
        this.sconto = sconto;
    }

    public int getId() {
        return id;
    }

    public int getSconto() {
        return sconto;
    }
    
}
