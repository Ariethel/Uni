package bancastdclient;

import banca.*;
import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BancaStdClient {
    
    private static CorrentistaEJBRemote ejb;

    public static void main(String[] args) throws NamingException {
        Context ctx = new InitialContext();
        
        ejb = (CorrentistaEJBRemote) ctx.lookup("java:global/BancaBean/CorrentistaEJB!banca.CorrentistaEJBRemote");
        
        System.out.println("Tutti i correntisti");
        List<Correntista> lista = ejb.getCorrentisti();
        for(Correntista c: lista)
            System.out.println(c);
        
        System.out.print("Inserisci un intero: ");
        Scanner s = new Scanner(System.in);
        Integer valore = s.nextInt();
        lista = ejb.getPerOperazioni(valore);
        for(Correntista c: lista)
            System.out.println(c);
        
        System.out.println("Tentativo di bonifico di 100 euro");
        Float valore2 = 100f;
        ejb.effettuaBonifico(1, valore2);
        
        System.out.println("Tentativo di bonifico di 20000 euro");
        valore2 = 20000f;
        ejb.effettuaBonifico(1, valore2);
        
    }
    
}
