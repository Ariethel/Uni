package banca;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface CorrentistaEJBRemote {
    void aggiungiCorrentista(Correntista c);
    void aggiornaCorrentista(Correntista c);
    void rimuoviCorrentista(Correntista c);
    
    List<Correntista> getCorrentisti();
    List<Correntista> getPerCognome(String cognome);
    List<Correntista> getPerImpiego(String impiego);
    List<Correntista> getPerInsolvenza(String insolvenza);
    List<Correntista> getPerOperazioni(Integer operazioni);
    List<Correntista> getPerBonificiInIngresso(Integer bonifici_ingresso);
    Correntista getCorrentista(Integer id);
    
    boolean effettuaBonifico(Integer id, Float importo);
}
