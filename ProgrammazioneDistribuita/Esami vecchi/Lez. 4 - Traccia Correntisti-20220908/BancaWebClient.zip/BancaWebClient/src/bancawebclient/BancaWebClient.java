package bancawebclient;

import java.util.List;

public class BancaWebClient {

    public static void main(String[] args) {
        Integer valore = 50;
        List<Correntista> lista = getPerBonificiInIngresso(valore);
        for(Correntista c : lista)
            System.out.println(c.getCognome() + " " + c.getNome());
    }

    private static java.util.List<bancawebclient.Correntista> getPerBonificiInIngresso(java.lang.Integer arg0) {
        bancawebclient.CorrentistaEJBService service = new bancawebclient.CorrentistaEJBService();
        bancawebclient.CorrentistaEJB port = service.getCorrentistaEJBPort();
        return port.getPerBonificiInIngresso(arg0);
    }
    
}
