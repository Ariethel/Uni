package banca;

import java.util.HashMap;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@Counter
public class CounterInterceptor {
    private HashMap<String, Integer> counterMap = new HashMap<String, Integer>();
    
    Integer maxValue = 0;
    String methodMaxValue = "";
    
    @AroundInvoke
    public Object logMethod(InvocationContext ic) throws Exception{
        if(!counterMap.containsKey(ic.getMethod().getName()))
            counterMap.put(ic.getMethod().getName(), 0);
        counterMap.put(ic.getMethod().getName(),counterMap.get(ic.getMethod().getName())+1);
        
        if(counterMap.get(ic.getMethod().getName())>maxValue){
            maxValue = counterMap.get(ic.getMethod().getName());
            methodMaxValue = ic.getMethod().getName();
        }
        
        System.out.println("Invocato metodo " + ic.getMethod().getName() + "(), " + 
            "numero invocazione " + counterMap.get(ic.getMethod().getName()) +
            ". Metodo con massimo numero di invocazioni " + methodMaxValue + "(), " + 
            " numero invocazioni massime " + maxValue + "." );
        
        return ic.proceed();
    } 
}
