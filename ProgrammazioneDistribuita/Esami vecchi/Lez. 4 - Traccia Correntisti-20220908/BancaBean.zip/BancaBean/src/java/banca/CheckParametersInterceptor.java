package banca;

import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;

@Interceptor
@CheckParameters
public class CheckParametersInterceptor {
    
    @AroundInvoke
    public Object check(InvocationContext ic) throws Exception{
        Float param = (Float)ic.getParameters()[1];
        if(param>15000){
            System.out.println("L'operazione non è andata a buon fine");
            return false;
        }
        return ic.proceed();
    }
    
}
