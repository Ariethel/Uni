package banca;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/EsameDS",
   user = "ok", password = "ok",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private CorrentistaEJB ejb;
    private Correntista e1, e2, e3;
    
    @PostConstruct
    private void populateDB(){
        e1 = new Correntista(1, "Rossi", "Mario", "Politico", "SI", 5000, 3, 7000, 10, 900000f, 3000f);
        e2 = new Correntista(2, "Verdi", "Michele", "Imprenditore", "NO", 10, 200, 500, 1000, 5000f, 100000f);
        e3 = new Correntista(3, "Bianchini", "Francesco", "Papa", "NO", 10, 10, 10, 10, 500f, 500f);
        
        ejb.aggiungiCorrentista(e1);
        ejb.aggiungiCorrentista(e2);
        ejb.aggiungiCorrentista(e3);
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviCorrentista(e1);
        ejb.rimuoviCorrentista(e2);
        ejb.rimuoviCorrentista(e3);
    }
    
    
}