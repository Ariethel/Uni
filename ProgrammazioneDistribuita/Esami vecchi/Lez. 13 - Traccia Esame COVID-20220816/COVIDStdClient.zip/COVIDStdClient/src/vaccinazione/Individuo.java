package vaccinazione;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import static vaccinazione.Individuo.*;

@Entity
@NamedQueries({
    @NamedQuery(name = FIND_ALL, query = "SELECT i FROM Individuo i"),
    @NamedQuery(name = FIND_BY_AGE, query = "SELECT i FROM Individuo i WHERE i.eta = :eta"),
    @NamedQuery(name = FIND_BY_CATEGORY, query = "SELECT i FROM Individuo i WHERE i.categoria = :categoria"),
    @NamedQuery(name = FIND_BY_COVID, query = "SELECT i FROM Individuo i WHERE i.covid = :contratto_covid"),
    @NamedQuery(name = FIND_BY_ID, query = "SELECT i FROM Individuo i WHERE i.id = ?1"),
    @NamedQuery(name = FIND_BY_CATEGORY_AND_AGE, query = "SELECT i FROM Individuo i WHERE i.categoria = :categoria AND i.eta < :eta"),
    @NamedQuery(name = FIND_BY_CATEGORY_AND_INTERESSE_VACCINO, query = "SELECT i FROM Individuo i WHERE i.categoria = :categoria AND i.interessati_al_vaccino = :interesse")
})
public class Individuo implements Serializable {
    public static final String FIND_BY_CATEGORY = "Individuo.findByCategory";
    public static final String FIND_BY_AGE = "Individuo.findByAge";
    public static final String FIND_BY_COVID = "Individuo.findByCOVID";
    public static final String FIND_ALL = "Individuo.findAll";
    public static final String FIND_BY_ID = "Individuo.findByID";
    public static final String FIND_BY_CATEGORY_AND_AGE = "Individuo.findByCategoryAndAge";
    public static final String FIND_BY_CATEGORY_AND_INTERESSE_VACCINO = "Individuo.findByCategoryAndInteresseVaccino";
    
    @Id
    private int id;
    private String cognome;
    private String nome;
    private String categoria; 
    private int eta;
    private String genere;
    private int malattie_pregresse;
    private boolean covid;
    private String interessati_al_vaccino;
    private String priorita;

    public Individuo() {
    }

    public Individuo(int id, String cognome, String nome, String categoria, int eta, String genere, int malattie_pregresse, boolean covid, String interessati_al_vaccino, String priorita) {
        this.id = id;
        this.cognome = cognome;
        this.nome = nome;
        this.categoria = categoria;
        this.eta = eta;
        this.genere = genere;
        this.malattie_pregresse = malattie_pregresse;
        this.covid = covid;
        this.interessati_al_vaccino = interessati_al_vaccino;
        this.priorita = priorita;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getEta() {
        return eta;
    }

    public void setEta(int eta) {
        this.eta = eta;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public int getMalattie_pregresse() {
        return malattie_pregresse;
    }

    public void setMalattie_pregresse(int malattie_pregresse) {
        this.malattie_pregresse = malattie_pregresse;
    }

    public boolean isCovid() {
        return covid;
    }

    public void setCovid(boolean covid) {
        this.covid = covid;
    }

    public String getInteressati_al_vaccino() {
        return interessati_al_vaccino;
    }

    public void setInteressati_al_vaccino(String interessati_al_vaccino) {
        this.interessati_al_vaccino = interessati_al_vaccino;
    }

    public String getPriorita() {
        return priorita;
    }

    public void setPriorita(String priorita) {
        this.priorita = priorita;
    }

    @Override
    public String toString() {
        return "Individuo{" + "id=" + id + ", cognome=" + cognome + ", nome=" + nome + ", categoria=" + categoria + ", eta=" + eta + ", genere=" + genere + ", malattie_pregresse=" + malattie_pregresse + ", covid=" + covid + ", interessati_al_vaccino=" + interessati_al_vaccino + ", priorita=" + priorita + '}';
    }
    
    
    
}
