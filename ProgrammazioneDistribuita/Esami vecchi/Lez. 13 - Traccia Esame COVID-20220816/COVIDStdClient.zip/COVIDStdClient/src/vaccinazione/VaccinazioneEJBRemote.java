package vaccinazione;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface VaccinazioneEJBRemote {
    void aggiungiIndividuo(Individuo i);
    Individuo aggiornaIndividuo(Individuo i);
    void rimuoviIndividuo(Individuo i);
    
    Individuo trovaPerID(int id);
    List<Individuo> trovaPerCategoria(String categoria);
    List<Individuo> trovaPerEta(int eta);
    List<Individuo> trovaPerCOVID(boolean contratto_covid);
    List<Individuo> trovaTutti();
    List<Individuo> trovaPerCategoriaEEta(String categoria, int eta);
    List<Individuo> trovaPerCategoriaEInteresseVaccino(String categoria, String interesse);
}
