package covidstdclient;

import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import vaccinazione.*;

public class COVIDStdClient {

    private static VaccinazioneEJBRemote ejb;
    public static void main(String[] args) throws NamingException {
        Context cxt = new InitialContext();
        ejb = (VaccinazioneEJBRemote) cxt.lookup("java:global/COVID/VaccinazioneEJB!vaccinazione.VaccinazioneEJBRemote");
        
        
        System.out.println("Individui che hanno contratto il COVID: ");
        List<Individuo> lista = ejb.trovaPerCOVID(true);
        for(Individuo i: lista)
            System.out.println(i);
        
        System.out.println("Docenti con meno di 55 anni: ");
        lista = ejb.trovaPerCategoriaEEta("Docente", 55);
        for(Individuo i: lista)
            System.out.println(i);
        
        
        System.out.println("Pensionati interessati al vaccino: ");
        lista = ejb.trovaPerCategoriaEInteresseVaccino("Pensionato", "si");
        for(Individuo i: lista)
            System.out.println(i);
    }
    
}
