package vaccinazione;

import javax.enterprise.event.Observes;

public class UpdateNotification {
    public void notify(@Observes Individuo p){
        System.out.println("Dati aggiornati: " + p);
    }
}