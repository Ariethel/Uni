package vaccinazione;

import javax.enterprise.event.Observes;

public class PensionatiAndInteressatiNotification {
    public void notify(@Observes @PensionatiInteressatiVaccino Individuo p){
        System.out.println("Ecco un altro individuo che ha la precedenza sul piano vaccinale");
    }
}