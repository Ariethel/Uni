package vaccinazione;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName = "jms/javaee7/Topic")
public class VaccinazioneMDB implements MessageListener {
    
    @Inject
    private VaccinazioneEJB ejb;

    @Inject 
    Event<Individuo> event;
    
    @Inject @PensionatiInteressatiVaccino
    Event<Individuo> specialEvent;
    
    @Override
    public void onMessage(Message msg) {
        try {
            MessageWrapper wrapper = msg.getBody(MessageWrapper.class);
            
            Integer id = wrapper.getId();
            String interesse = wrapper.getInteresse();
            
            Individuo p = ejb.trovaPerID(id);
            p.setInteressati_al_vaccino(interesse);
            if(p.getMalattie_pregresse()>2)
                p.setPriorita("alta");
            ejb.aggiornaIndividuo(p);
            
            if(p.getCategoria().equals("Pensionato") && interesse.equals("si"))
                specialEvent.fire(p);
            else
                event.fire(p);
        } catch (JMSException ex) {
            Logger.getLogger(VaccinazioneMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
