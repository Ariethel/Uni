package vaccinazione;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/EsameDS",
   user = "ok", password = "ok",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private VaccinazioneEJB ejb;
    private Individuo p1, p2, p3;
    
    @PostConstruct
    private void populateDB(){
        //p1 = new Individuo(1, "Rossi", "Luigi", "Pensionato", 65, "M", 2, true, "no", "media");
        p1 = new Individuo(1, "Rossi", "Luigi", "Pensionato", 65, "M", 3, true, "no", "media");
        p2 = new Individuo(2, "Bianchi", "Maria", "Docente", 45, "F", 0, false, "no", "bassa");
        p3 = new Individuo(3, "Verdi", "Giovanni", "Pensionato", 67, "M", 1, false, "si", "alta");
        
        ejb.aggiungiIndividuo(p1);
        ejb.aggiungiIndividuo(p2);
        ejb.aggiungiIndividuo(p3);
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviIndividuo(p1);
        ejb.rimuoviIndividuo(p2);
        ejb.rimuoviIndividuo(p3);
    }
    
    
}