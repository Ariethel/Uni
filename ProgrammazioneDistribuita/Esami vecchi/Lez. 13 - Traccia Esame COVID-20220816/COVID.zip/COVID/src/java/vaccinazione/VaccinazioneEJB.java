package vaccinazione;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateless
@LocalBean
public class VaccinazioneEJB implements VaccinazioneEJBRemote {

    @Inject
    private EntityManager em;
    
    @Override
    public void aggiungiIndividuo(Individuo i) {
        em.persist(i);
    }

    @Override
    public Individuo aggiornaIndividuo(Individuo i) {
        return em.merge(i);
    }

    @Override
    public void rimuoviIndividuo(Individuo i) {
        em.remove(em.merge(i));
    }

    @Override
    public Individuo trovaPerID(int id) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_ID, Individuo.class);
        query.setParameter(1, id);
        return query.getSingleResult();
    }

    @Override
    public List<Individuo> trovaPerCategoria(String categoria) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_CATEGORY, Individuo.class);
        query.setParameter("categoria", categoria);
        return query.getResultList();
    }

    @Override
    public List<Individuo> trovaPerEta(int eta) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_AGE, Individuo.class);
        query.setParameter("eta", eta);
        return query.getResultList();
    }

    @Override
    public List<Individuo> trovaPerCOVID(boolean contratto_covid) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_COVID, Individuo.class);
        query.setParameter("contratto_covid", contratto_covid);
        return query.getResultList();
    }

    @Override
    public List<Individuo> trovaTutti() {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_ALL, Individuo.class);
        return query.getResultList();
    }

    @Override
    public List<Individuo> trovaPerCategoriaEEta(String categoria, int eta) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_CATEGORY_AND_AGE, Individuo.class);
        query.setParameter("categoria", categoria);
        query.setParameter("eta", eta);
        return query.getResultList();
    }

    @Override
    public List<Individuo> trovaPerCategoriaEInteresseVaccino(String categoria, String interesse) {
        TypedQuery<Individuo> query = em.createNamedQuery(Individuo.FIND_BY_CATEGORY_AND_INTERESSE_VACCINO, Individuo.class);
        query.setParameter("categoria", categoria);
        query.setParameter("interesse", interesse);
        return query.getResultList();
    }
    

}
