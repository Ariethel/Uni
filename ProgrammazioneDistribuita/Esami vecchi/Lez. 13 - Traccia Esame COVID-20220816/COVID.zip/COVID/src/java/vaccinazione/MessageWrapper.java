package vaccinazione;

import java.io.Serializable;

public class MessageWrapper implements Serializable {
    private int id;
    private String interesse;

    public MessageWrapper(int id, String interesse) {
        this.id = id;
        this.interesse = interesse;
    }

    public int getId() {
        return id;
    }

    public String getInteresse() {
        return interesse;
    }
    
    
}
