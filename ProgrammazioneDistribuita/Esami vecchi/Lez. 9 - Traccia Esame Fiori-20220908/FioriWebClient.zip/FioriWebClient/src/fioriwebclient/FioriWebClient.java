package fioriwebclient;

import java.util.List;

public class FioriWebClient {

    public static void main(String[] args) {
        List<fiore.Fiore> lista = cercaPerProprieta("Antinfiammatorie");
        for(fiore.Fiore f:lista)
            System.out.println(f.getSpecie());
    }

    private static java.util.List<fiore.Fiore> cercaPerProprieta(java.lang.String arg0) {
        fiore.FioreEJBService service = new fiore.FioreEJBService();
        fiore.FioreEJB port = service.getFioreEJBPort();
        return port.cercaPerProprieta(arg0);
    }
    
}
