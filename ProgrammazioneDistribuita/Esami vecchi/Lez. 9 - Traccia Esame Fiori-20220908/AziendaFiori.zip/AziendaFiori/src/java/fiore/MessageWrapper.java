package fiore;

import java.io.Serializable;

public class MessageWrapper implements Serializable {
    private int id;
    private int giacenza;

    public MessageWrapper(int id, int giacenza) {
        this.id = id;
        this.giacenza = giacenza;
    }

    public int getId() {
        return id;
    }

    public int getGiacenza() {
        return giacenza;
    }
    
    
}
