package fiore;

import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Stateless
@LocalBean
@WebService
public class FioreEJB implements FioreEJBRemote {

    @Inject
    private EntityManager em;

    @Override
    public void aggiungiFiore(Fiore f) {
        em.persist(f);
    }

    @Override
    public Fiore aggiornaFiore(Fiore f) {
        return em.merge(f);
    }

    @Override
    public void rimuoviFiore(Fiore f) {
        em.remove(em.merge(f));
    }

    @Override
    public Fiore cercaPerId(int id) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_ID, Fiore.class);
        query.setParameter(1, id);
        return query.getSingleResult();
    }

    @Override
    public List<Fiore> cercaTutti() {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_TUTTI, Fiore.class);
        return query.getResultList();
    }

    @Override
    public List<Fiore> cercaPerCicloBiologico(String ciclo) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_CICLO_BIOLOGICO, Fiore.class);
        query.setParameter("ciclo", ciclo);
        return query.getResultList();
    }

    @Override
    public List<Fiore> cercaPerColore(String colore) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_COLORE, Fiore.class);
        query.setParameter("colore", colore);
        return query.getResultList();
    }

    @Override
    public List<Fiore> cercaPerParassita(String parassita) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_PARASSITA, Fiore.class);
        query.setParameter("parassita", parassita);
        return query.getResultList();
    }

    @Override
    public List<Fiore> cercaPerUso(String uso) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_USO, Fiore.class);
        query.setParameter("uso", uso);
        return query.getResultList();
    }

    @Override
    public List<Fiore> cercaPerProprieta(String proprieta) {
        TypedQuery<Fiore> query = em.createNamedQuery(Fiore.TROVA_PER_PROPRIETA, Fiore.class);
        query.setParameter("proprieta", proprieta);
        return query.getResultList();
    }
    
    
}
