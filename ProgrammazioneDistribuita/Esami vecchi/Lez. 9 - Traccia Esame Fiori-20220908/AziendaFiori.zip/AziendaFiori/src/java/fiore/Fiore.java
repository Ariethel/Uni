package fiore;

import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import static fiore.Fiore.*;
import java.io.Serializable;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@NamedQueries({
    @NamedQuery(name = TROVA_TUTTI, query = "SELECT f FROM Fiore f"),
    @NamedQuery(name = TROVA_PER_ID, query = "SELECT f FROM Fiore f WHERE f.id = ?1"),
    @NamedQuery(name = TROVA_PER_CICLO_BIOLOGICO, query = "SELECT f FROM Fiore f WHERE f.ciclo = :ciclo"),
    @NamedQuery(name = TROVA_PER_COLORE, query = "SELECT f FROM Fiore f WHERE f.colore = :colore"),
    @NamedQuery(name = TROVA_PER_PARASSITA, query = "SELECT f FROM Fiore f WHERE f.parassita = :parassita"),
    @NamedQuery(name = TROVA_PER_USO, query = "SELECT f FROM Fiore f WHERE f.uso = :uso"),
    @NamedQuery(name = TROVA_PER_PROPRIETA, query = "SELECT f FROM Fiore f WHERE f.proprieta = :proprieta")
})
@XmlRootElement
public class Fiore implements Serializable {
    public static final String TROVA_TUTTI = "Fiore.trovaTutti";
    public static final String TROVA_PER_ID = "Fiore.trovaPerId";
    public static final String TROVA_PER_CICLO_BIOLOGICO = "Fiore.trovaPerCicloBiologico";
    public static final String TROVA_PER_COLORE = "Fiore.trovaPerColore";
    public static final String TROVA_PER_PARASSITA = "Fiore.trovaPerParassita";
    public static final String TROVA_PER_USO = "Fiore.trovaPerUso";
    public static final String TROVA_PER_PROPRIETA = "Fiore.trovaPerProprieta";

    @Id
    private int id;
    private String specie;
    private String famiglia_botanica;
    private String ciclo;
    private String origine;
    private String proprieta;
    private String colore;
    private String parassita;
    private String uso;
    private int giacenza;

    public Fiore() {
    }

    public Fiore(int id, String specie, String famiglia_botanica, String ciclo, String origine, String proprieta, String colore, String parassita, String uso, int giacenza) {
        this.id = id;
        this.specie = specie;
        this.famiglia_botanica = famiglia_botanica;
        this.ciclo = ciclo;
        this.origine = origine;
        this.proprieta = proprieta;
        this.colore = colore;
        this.parassita = parassita;
        this.uso = uso;
        this.giacenza = giacenza;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSpecie() {
        return specie;
    }

    public void setSpecie(String specie) {
        this.specie = specie;
    }

    public String getFamiglia_botanica() {
        return famiglia_botanica;
    }

    public void setFamiglia_botanica(String famiglia_botanica) {
        this.famiglia_botanica = famiglia_botanica;
    }

    public String getCiclo() {
        return ciclo;
    }

    public void setCiclo(String ciclo) {
        this.ciclo = ciclo;
    }

    public String getOrigine() {
        return origine;
    }

    public void setOrigine(String origine) {
        this.origine = origine;
    }

    public String getProprieta() {
        return proprieta;
    }

    public void setProprieta(String proprieta) {
        this.proprieta = proprieta;
    }

    public String getColore() {
        return colore;
    }

    public void setColore(String colore) {
        this.colore = colore;
    }

    public String getParassita() {
        return parassita;
    }

    public void setParassita(String parassita) {
        this.parassita = parassita;
    }

    public String getUso() {
        return uso;
    }

    public void setUso(String uso) {
        this.uso = uso;
    }

    public int getGiacenza() {
        return giacenza;
    }

    public void setGiacenza(int giacenza) {
        this.giacenza = giacenza;
    }

    @Override
    public String toString() {
        return "Fiore{" + "id=" + id + ", specie=" + specie + ", famiglia_botanica=" + famiglia_botanica + ", ciclo=" + ciclo + ", origine=" + origine + ", proprieta=" + proprieta + ", colore=" + colore + ", parassita=" + parassita + ", uso=" + uso + ", giacenza=" + giacenza + '}';
    }
    
    
}
