package fiore;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName = "jms/javaee7/Topic")
public class FioreMDB implements MessageListener {

    @Inject
    private FioreEJB ejb;
    
    @Inject
    private Event<Fiore> event;
    
    @Override
    public void onMessage(Message message) {
        try {
            MessageWrapper wrapper = message.getBody(MessageWrapper.class);
        
            int id = wrapper.getId();
            int giacenza = wrapper.getGiacenza();
            
            Fiore f = ejb.cercaPerId(id);
            f.setGiacenza(giacenza + f.getGiacenza());
            f = ejb.aggiornaFiore(f);
            
            if(f.getGiacenza()<10)
                event.fire(f);
        } catch (JMSException ex) {
            Logger.getLogger(FioreMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
