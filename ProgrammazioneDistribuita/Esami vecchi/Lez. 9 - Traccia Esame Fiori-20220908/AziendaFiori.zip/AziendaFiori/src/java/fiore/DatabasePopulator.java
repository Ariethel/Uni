package fiore;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.sql.DataSourceDefinition;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
@DataSourceDefinition(
   className = "org.apache.derby.jdbc.EmbeddedDataSource",
   name = "java:global/jdbc/EsameDS",
   user = "ok", password = "ok",
   databaseName = "EsameDB",
   properties = {"connectionAttributes=;create=true"}
)
public class DatabasePopulator {
    
    @Inject
    private FioreEJB ejb;
    private Fiore f1, f2, f3;
    
    @PostConstruct
    private void populateDB(){
        f1 = new Fiore(1, "Petunia", "Solanaceae", "Annuale", "South America", "Antiossidante", "Rosa", "Acari", "Dolci", 12);
        f2 = new Fiore(2, "Calendula", "Asteraceae", "Perenne", "South Europe", "Antinfiammatorie", "Arancio", "Oidio", "Infusi", 34);
        f3 = new Fiore(3, "Viola del pensiero", "Violaceae", "Annuale", "Europe", "Antinfiammatorie", "Viola", "Afidi neri", "Insalate", 15);
    
        ejb.aggiungiFiore(f1);
        ejb.aggiungiFiore(f2);
        ejb.aggiungiFiore(f3);
    }
    
    @PreDestroy
    private void clearDB(){
        ejb.rimuoviFiore(f1);
        ejb.rimuoviFiore(f2);
        ejb.rimuoviFiore(f3);
    }
    
    
}