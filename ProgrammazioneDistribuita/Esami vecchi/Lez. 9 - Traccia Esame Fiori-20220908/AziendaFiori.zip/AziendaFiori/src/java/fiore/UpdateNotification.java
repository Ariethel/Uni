package fiore;

import javax.enterprise.event.Observes;

public class UpdateNotification {
    public void notify(@Observes Fiore f){
        System.out.println("Giacenza bassa per il prodotto " + f);
    }
}