package fioristdclient;

import fiore.*;
import java.util.List;
import java.util.Scanner;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class FioriStdClient {

    private static FioreEJBRemote ejb; 
    
    public static void main(String[] args) throws NamingException {
        Context cxt = new InitialContext();
        ejb = (FioreEJBRemote) cxt.lookup("java:global/AziendaFiori/FioreEJB!fiore.FioreEJBRemote");
        
        System.out.print("Ciclo biologico:");
        Scanner scanner = new Scanner(System.in);
        String ciclo = scanner.nextLine();
        List<Fiore> lista = ejb.cercaPerCicloBiologico(ciclo);
        for(Fiore f:lista)
            System.out.println(f);
        
        System.out.println("Fiori per dolci");
        lista = ejb.cercaPerUso("Dolci");
        for(Fiore f:lista)
            System.out.println(f);        
        
    }
    
}
