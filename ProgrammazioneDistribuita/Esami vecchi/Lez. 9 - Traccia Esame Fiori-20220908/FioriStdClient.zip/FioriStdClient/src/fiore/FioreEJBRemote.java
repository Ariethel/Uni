package fiore;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface FioreEJBRemote {
    void aggiungiFiore(Fiore f);
    Fiore aggiornaFiore(Fiore f);
    void rimuoviFiore(Fiore f);
    
    Fiore cercaPerId(int id);
    List<Fiore> cercaTutti();
    List<Fiore> cercaPerCicloBiologico(String ciclo);
    List<Fiore> cercaPerColore(String colore);
    List<Fiore> cercaPerParassita(String parassita);
    List<Fiore> cercaPerUso(String uso);
    List<Fiore> cercaPerProprieta(String proprieta);
}
