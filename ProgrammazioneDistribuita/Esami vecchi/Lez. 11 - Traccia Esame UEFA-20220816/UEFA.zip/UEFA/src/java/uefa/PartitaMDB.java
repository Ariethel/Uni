package uefa;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.MessageDriven;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

@MessageDriven(mappedName = "jms/javaee7/Topic")
public class PartitaMDB implements MessageListener {
    
    @Inject
    private PartitaEJB ejb;

    @Inject 
    Event<Partita> event;
    
    @Inject @Italia
    Event<Partita> italiaEvent;
    
    @Override
    public void onMessage(Message msg) {
        try {
            MessageWrapper wrapper = msg.getBody(MessageWrapper.class);
            
            Integer id = wrapper.getId();
            Integer numero_goal = wrapper.getNumero_goal();
            String squadra = wrapper.getSquadra();
            
            Partita p = ejb.trovaPerId(id);
            if(p.getSc().equals(squadra))
                p.setNumero_goal_sc(p.getNumero_goal_sc()+numero_goal);
            else if(p.getSo().equals(squadra))
                p.setNumero_goal_so(p.getNumero_goal_so()+numero_goal);
            p = ejb.aggiornaPartita(p);
            
            if(squadra.equals("Italia"))
                italiaEvent.fire(p);
            else
                event.fire(p);
        } catch (JMSException ex) {
            Logger.getLogger(PartitaMDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}