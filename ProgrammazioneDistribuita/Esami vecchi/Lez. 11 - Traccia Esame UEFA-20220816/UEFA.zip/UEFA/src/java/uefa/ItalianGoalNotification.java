package uefa;

import javax.enterprise.event.Observes;

public class ItalianGoalNotification {
    public void notify(@Observes @Italia Partita p){
        System.out.println("Aleeeeeeee :-)");
    }
}