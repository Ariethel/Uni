package uefawebclient;

import java.util.List;
import uefa.Partita;

public class UEFAWebClient {

    public static void main(String[] args) {
        List<Partita> lista = trovaTutte();
        for(Partita p:lista)
            System.out.println(p.getTipoPartita() + ": " + p.getSc() + "-" + p.getNumeroGoalSc() + " VS " + p.getSo() + "-" + p.getNumeroGoalSo());
    }

    private static java.util.List<uefa.Partita> trovaTutte() {
        uefa.PartitaEJBService service = new uefa.PartitaEJBService();
        uefa.PartitaEJB port = service.getPartitaEJBPort();
        return port.trovaTutte();
    }
    
}
