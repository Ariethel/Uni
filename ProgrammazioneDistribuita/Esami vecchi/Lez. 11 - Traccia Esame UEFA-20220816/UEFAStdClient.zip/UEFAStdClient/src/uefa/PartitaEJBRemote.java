package uefa;

import java.util.List;
import javax.ejb.Remote;

@Remote
public interface PartitaEJBRemote {
    void aggiungiPartita(Partita p);
    Partita aggiornaPartita(Partita p);
    void rimuoviPartita(Partita p);
    
    Partita trovaPerId(int id);
    List<Partita> trovaPerTipoPartita(String tipo_partita);
    List<Partita> trovaPerNumeroAmmonizioni(int numero_ammonizioni);
    List<Partita> trovaPerNumeroEspulsioni(int numero_espulsioni);
    List<Partita> trovaPerNumeroGoal(int numero_goal);
    List<Partita> trovaTutte();
}
