package uefastdclient;

import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import uefa.*;

public class UEFAStdClient {

    private static PartitaEJBRemote ejb;
    public static void main(String[] args) throws NamingException {
        Context ctx = new InitialContext();
        ejb = (PartitaEJBRemote) ctx.lookup("java:global/UEFA/PartitaEJB!uefa.PartitaEJBRemote");
        
        System.out.println("Partite con più di 2 goal");
        List<Partita> lista = ejb.trovaPerNumeroGoal(2);
        for(Partita p:lista)
            System.out.println(p);
        
        System.out.println("Partite con 0 ammonizioni");
        lista = ejb.trovaPerNumeroAmmonizioni(0);
        for(Partita p:lista)
            System.out.println(p);
    }
    
}
